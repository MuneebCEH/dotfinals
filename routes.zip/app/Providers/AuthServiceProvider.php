<?php

namespace App\Providers;

use App\Models\Callback;
use App\Models\Lead;
use App\Models\LeadIssue;
use App\Models\Note;
use App\Policies\CallbackPolicy;
use App\Policies\LeadIssuePolicy;
use App\Policies\LeadPolicy;
use App\Policies\NotePolicy;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        Lead::class => LeadPolicy::class,
        Note::class => NotePolicy::class,
        Callback::class => CallbackPolicy::class,
        LeadIssue::class => LeadIssuePolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        $this->registerPolicies();

        // Define admin check
        Gate::define('admin', function ($user) {
            return $user->role === 'admin';
        });
    }
}

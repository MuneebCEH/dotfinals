<?php

namespace App\Http\Controllers;

use App\Models\Attachment; // adjust namespace if different
use App\Models\LeadIssue;
use Illuminate\Http\Request;

class AttachmentController extends Controller
{
    /**
     * Inline-preview an attachment (best-effort anti-download).
     * Serves from storage/app/public/<file_path>.
     */
    public function preview(LeadIssue $attachment, Request $request)
    {
        // Must be logged in & authorized to view this file
        $this->authorize('view', $attachment);

        // Resolve path (we store relative paths like "issues/123/abc.png")
        $relPath = ltrim($attachment->file_path, '/');
        $absPath = storage_path('app/public/' . $relPath);

        abort_unless(file_exists($absPath), 404, 'File not found.');

        // Serve inline + no-store headers; avoid "attachment" disposition
        $headers = [
            'Content-Type'        => $attachment->file_type ?: 'application/octet-stream',
            'Content-Disposition' => 'inline; filename="' . addslashes($attachment->file_name ?: basename($relPath)) . '"',
            'Cache-Control'       => 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma'              => 'no-cache',
            'Expires'             => '0',
            // Optional hardening:
            // 'X-Frame-Options' => 'DENY',
            // 'Referrer-Policy' => 'no-referrer',
            // 'Content-Security-Policy' => "default-src 'self'; img-src 'self' data: blob:; object-src 'none';",
        ];

        return response()->file($absPath, $headers);
    }
}

@extends('layouts.app')

@section('title', 'Issue Responses')
@section('page-title', 'Issue Responses')

@section('content')
    <div class="mx-auto space-y-6 animate-on-load">

        <div
            class="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl shadow-2xl rounded-2xl border border-gray-200/50 dark:border-gray-700/50 overflow-hidden">
            <div class="px-8 py-6 flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <div
                        class="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary-500 to-primary-600 flex items-center justify-center shadow-lg">
                        <svg class="w-7 h-7 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                            <path
                                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </div>
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">{{ $issue->title }}</h1>
                        <p class="text-gray-600 dark:text-gray-400">
                            <span
                                class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium {{ $issue->priority === 'high' ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300' : ($issue->priority === 'medium' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300' : 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300') }}">
                                {{ ucfirst($issue->priority) }} Priority
                            </span>
                            <span
                                class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium {{ $issue->status === 'open' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300' : ($issue->status === 'in_progress' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300' : 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300') }}">
                                {{ ucfirst(str_replace('_', ' ', $issue->status)) }}
                            </span>
                            <span class="ml-2 text-sm">Reported {{ $issue->created_at->diffForHumans() }}</span>
                        </p>
                    </div>
                </div>
                <a href="{{ route('leads.edit', $issue->lead_id) }}"
                    class="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 bg-white/80 dark:bg-gray-700/80 backdrop-blur-xl font-medium rounded-lg hover:bg-gray-50 dark:hover:bg-gray-600 transition">
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                    </svg>
                    Back to Lead
                </a>
            </div>

            <div class="px-8 pb-6 space-y-6">
                <!-- Issue Description -->
                <div
                    class="p-4 rounded-xl bg-gray-50/70 dark:bg-gray-700/50 border border-gray-200/70 dark:border-gray-600/50">
                    <h3 class="font-semibold text-gray-900 dark:text-white mb-2">Description</h3>
                    <div class="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{{ $issue->description }}</div>
                </div>

                <!-- Issue Attachments -->
                @if (isset($issue) &&
                        $issue->attachments &&
                        $issue->attachments->where('is_solution', false)->where('issue_comment_id', null)->count() > 0)
                    <div>
                        <h3 class="font-semibold text-gray-900 dark:text-white mb-2">Attachments</h3>
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                            @foreach ($issue->attachments->where('is_solution', false)->where('issue_comment_id', null) as $attachment)
                                <a href="{{ Storage::url($attachment->file_path) }}" target="_blank"
                                    class="flex items-center p-3 rounded-lg border border-gray-200/70 dark:border-gray-600/50 bg-white/70 dark:bg-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-600/50 transition">
                                    <div
                                        class="shrink-0 w-10 h-10 rounded-lg bg-gray-100 dark:bg-gray-600 flex items-center justify-center mr-3">
                                        <svg class="w-6 h-6 text-gray-500 dark:text-gray-400" fill="none"
                                            stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                        </svg>
                                    </div>
                                    <div class="min-w-0 flex-1">
                                        <p class="text-sm font-medium text-gray-900 dark:text-white truncate">
                                            {{ $attachment->file_name }}</p>
                                        <p class="text-xs text-gray-500 dark:text-gray-400">
                                            {{ number_format($attachment->file_size / 1024, 1) }} KB</p>
                                    </div>
                                </a>
                            @endforeach
                        </div>
                    </div>
                @endif


                <!-- Resolution Information (if resolved) -->
                @if ($issue->status === 'resolved')
                    <div
                        class="p-4 rounded-xl bg-green-50/70 dark:bg-green-900/20 border border-green-200/70 dark:border-green-800/50">
                        <h3 class="font-semibold text-gray-900 dark:text-white mb-2">Resolution</h3>
                        <div class="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{{ $issue->resolution }}</div>

                        <!-- Solution Files -->
                        {{-- @if ($issue->attachments->where('is_solution', true)->count() > 0)
                            <div class="mt-4">
                                <h4 class="font-medium text-gray-900 dark:text-white mb-2">Solution Files</h4>
                                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                                    @foreach ($issue->attachments->where('is_solution', true) as $attachment)
                                        <a href="{{ Storage::url($attachment->file_path) }}" target="_blank"
                                            class="flex items-center p-3 rounded-lg border border-green-200/70 dark:border-green-800/50 bg-white/70 dark:bg-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-600/50 transition">
                                            <div
                                                class="shrink-0 w-10 h-10 rounded-lg bg-green-100 dark:bg-green-800/50 flex items-center justify-center mr-3">
                                                <svg class="w-6 h-6 text-green-600 dark:text-green-400" fill="none"
                                                    stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                </svg>
                                            </div>
                                            <div class="min-w-0 flex-1">
                                                <p class="text-sm font-medium text-gray-900 dark:text-white truncate">
                                                    {{ $attachment->file_name }}</p>
                                                <p class="text-xs text-gray-500 dark:text-gray-400">
                                                    {{ number_format($attachment->file_size / 1024, 1) }} KB</p>
                                            </div>
                                        </a>
                                    @endforeach
                                </div>
                            </div>
                        @endif --}}
                    </div>
                @endif

                <!-- Comments Section -->
                <div class="mt-8">
                    <h3 class="font-semibold text-gray-900 dark:text-white mb-4">Comments</h3>

                    <div id="commentsList" class="space-y-4">
                        @forelse($issue->comments as $comment)
                            <div
                                class="p-4 rounded-xl bg-white/70 dark:bg-gray-700/50 border border-gray-200/70 dark:border-gray-600/50">
                                <div class="flex items-center justify-between mb-2">
                                    <div class="flex items-center">
                                        <div
                                            class="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center mr-2">
                                            <span
                                                class="text-sm font-medium text-gray-700 dark:text-gray-300">{{ substr($comment->author->name, 0, 1) }}</span>
                                        </div>
                                        <div>
                                            <span
                                                class="font-medium text-gray-900 dark:text-white">{{ $comment->author->name }}</span>
                                            @if (in_array($comment->author->role, ['admin', 'report_manager']))
                                                <span
                                                    class="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300">
                                                    {{ $comment->author->role === 'admin' ? 'Admin' : 'Report Manager' }}
                                                </span>
                                            @endif
                                        </div>
                                    </div>
                                    <span
                                        class="text-sm text-gray-500 dark:text-gray-400">{{ $comment->created_at->diffForHumans() }}</span>
                                </div>
                                <div class="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{{ $comment->body }}
                                </div>

                                <!-- Comment Attachments -->
                                @if ($comment->attachments->count() > 0)
                                    <div class="mt-3 pt-3 border-t border-gray-200/70 dark:border-gray-600/50">
                                        <h4 class="text-sm font-medium text-gray-900 dark:text-white mb-2">Attachments</h4>
                                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                            @foreach ($comment->attachments as $attachment)
                                                <a href="{{ Storage::url($attachment->file_path) }}" target="_blank"
                                                    class="flex items-center p-2 rounded-lg border border-gray-200/70 dark:border-gray-600/50 bg-gray-50/70 dark:bg-gray-600/50 hover:bg-gray-100 dark:hover:bg-gray-500/50 transition">
                                                    <div
                                                        class="shrink-0 w-8 h-8 rounded-lg bg-gray-100 dark:bg-gray-500 flex items-center justify-center mr-2">
                                                        <svg class="w-5 h-5 text-gray-500 dark:text-gray-300" fill="none"
                                                            stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                                stroke-width="2"
                                                                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                                        </svg>
                                                    </div>
                                                    <div class="min-w-0 flex-1">
                                                        <p
                                                            class="text-sm font-medium text-gray-900 dark:text-white truncate">
                                                            {{ $attachment->file_name }}</p>
                                                        <p class="text-xs text-gray-500 dark:text-gray-400">
                                                            {{ number_format($attachment->file_size / 1024, 1) }} KB</p>
                                                    </div>
                                                </a>
                                            @endforeach
                                        </div>
                                    </div>
                                @endif
                            </div>
                        @empty
                            <div id="noComments" class="text-center py-8 text-gray-500 dark:text-gray-400">No comments yet.
                            </div>
                        @endforelse
                    </div>


                    <!-- Add Comment Form -->
                    <div
                        class="rounded-xl border border-gray-200/60 dark:border-gray-700/60 bg-white/70 dark:bg-gray-800/50 p-4">
                        <h4 class="text-lg font-semibold text-gray-900 dark:text-white mb-3">Add a Comment</h4>
                        <form method="POST" action="{{ route('issues.comments.store', $issue) }}" class="space-y-4"
                            enctype="multipart/form-data">
                            @csrf

                            <div>
                                <textarea name="body" rows="3" required
                                    class="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-white/80 dark:bg-gray-700/80 focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                                    placeholder="Write your comment here..."></textarea>
                            </div>

                            <div>
                                <label for="comment_attachments"
                                    class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Attachments
                                    (Optional)</label>
                                <input type="file" name="comment_attachments[]" id="comment_attachments" multiple
                                    class="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-white/80 dark:bg-gray-700/80 focus:ring-2 focus:ring-primary-500 focus:border-primary-500">
                                <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">Upload screenshots or relevant
                                    files
                                    (max 10MB each)</p>
                            </div>

                            <div class="flex justify-end">
                                <button type="submit"
                                    class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-primary-500 to-primary-600 text-white shadow hover:shadow-lg transition">
                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                        <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Post Comment
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- Add Comment Form -->
                    {{-- <form method="POST" action="{{ route('issues.comments.store', $issue) }}" class="mt-6"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="space-y-4">
                            <div>
                                <label for="body"
                                    class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Add a
                                    Comment</label>
                                <textarea id="body" name="body" rows="3"
                                    class="w-full rounded-xl border-gray-300 dark:border-gray-600 bg-white/70 dark:bg-gray-700/50 text-gray-900 dark:text-white shadow-sm focus:border-primary-500 focus:ring-primary-500"
                                    required></textarea>
                            </div>
                            <div>
                                <label for="comment_attachments"
                                    class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Attachments
                                    (Optional)</label>
                                <input type="file" id="comment_attachments" name="comment_attachments[]" multiple
                                    class="w-full rounded-xl border-gray-300 dark:border-gray-600 bg-white/70 dark:bg-gray-700/50 text-gray-900 dark:text-white shadow-sm focus:border-primary-500 focus:ring-primary-500">
                                <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">Max 10MB per file</p>
                            </div>
                            <div class="flex justify-end">
                                <button type="submit"
                                    class="inline-flex items-center px-4 py-2 bg-primary-600 border border-transparent rounded-lg font-medium text-white hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition">
                                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                                    </svg>
                                    Post Comment
                                </button>
                            </div>
                        </div>
                    </form> --}}
                </div>
            </div>
        </div>
    </div>

    @push('scripts')
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Only initialize Echo if it exists (loaded in bootstrap.js)
                if (window.Echo) {
                    // Listen for issue status updates
                    window.Echo.private('issue.{{ $issue->id }}')
                        .listen('.issue.status.updated', (e) => {
                            // Reload the page to show updated status
                            window.location.reload();
                        })
                        .listen('.issue.comment.added', (e) => {
                            // Remove "no comments" message if it exists
                            const noCommentsEl = document.getElementById('noComments');
                            if (noCommentsEl) {
                                noCommentsEl.remove();
                            }

                            // Add the new comment to the list
                            const commentsList = document.getElementById('commentsList');
                            const commentEl = createCommentElement(e);
                            commentsList.insertAdjacentHTML('beforeend', commentEl);
                        });
                }

                // Function to create a comment element from event data
                function createCommentElement(data) {
                    const attachmentsHtml = data.attachments && data.attachments.length > 0 ?
                        `
                            <div class="mt-3 pt-3 border-t border-gray-200/70 dark:border-gray-600/50">
                                <h4 class="text-sm font-medium text-gray-900 dark:text-white mb-2">Attachments</h4>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                    ${data.attachments.map(att => `
                                                        <a href="${att.url}" target="_blank" class="flex items-center p-2 rounded-lg border border-gray-200/70 dark:border-gray-600/50 bg-gray-50/70 dark:bg-gray-600/50 hover:bg-gray-100 dark:hover:bg-gray-500/50 transition">
                                                            <div class="shrink-0 w-8 h-8 rounded-lg bg-gray-100 dark:bg-gray-500 flex items-center justify-center mr-2">
                                                                <svg class="w-5 h-5 text-gray-500 dark:text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                                                </svg>
                                                            </div>
                                                            <div class="min-w-0 flex-1">
                                                                <p class="text-sm font-medium text-gray-900 dark:text-white truncate">${att.file_name}</p>
                                                                <p class="text-xs text-gray-500 dark:text-gray-400">${(att.file_size / 1024).toFixed(1)} KB</p>
                                                            </div>
                                                        </a>
                                                    `).join('')}
                                </div>
                            </div>
                        ` :
                        '';

                    // Check if the author is admin or report_manager
                    const roleTag = data.author_role === 'admin' || data.author_role === 'report_manager' ?
                        `<span class="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300">
                            ${data.author_role === 'admin' ? 'Admin' : 'Report Manager'}
                          </span>` :
                        '';

                    return `
                        <div class="p-4 rounded-xl bg-white/70 dark:bg-gray-700/50 border border-gray-200/70 dark:border-gray-600/50">
                            <div class="flex items-center justify-between mb-2">
                                <div class="flex items-center">
                                    <div class="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center mr-2">
                                        <span class="text-sm font-medium text-gray-700 dark:text-gray-300">${data.author_name.charAt(0)}</span>
                                    </div>
                                    <div>
                                        <span class="font-medium text-gray-900 dark:text-white">${data.author_name}</span>
                                        ${roleTag}
                                    </div>
                                </div>
                                <span class="text-sm text-gray-500 dark:text-gray-400">Just now</span>
                            </div>
                            <div class="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">${data.body}</div>
                            ${attachmentsHtml}
                        </div>
                    `;
                }
            });
        </script>
    @endpush
@endsection
